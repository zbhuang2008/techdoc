# 定义一个句子列表，后面会用这些句子来训练 CBOW 和 Skip-Gram 模型
sentences = ["Kage is Teacher", "Mazong is Boss", "Niuzong is Boss",
             "Xiaobing is Student", "Xiaoxue is Student",]
# 将所有句子连接在一起，然后用空格分隔成多个单词
words = ' '.join(sentences).split()
# 构建词汇表，去除重复的词
word_list = list(set(words))
# 创建一个字典，将每个词映射到一个唯一的索引
word_to_idx = {word: idx for idx, word in enumerate(word_list)}
# 创建一个字典，将每个索引映射到对应的词
idx_to_word = {idx: word for idx, word in enumerate(word_list)}
voc_size = len(word_list) # 计算词汇表的大小
print(" 词汇表：", word_list) # 输出词汇表
print(" 词汇到索引的字典：", word_to_idx) # 输出词汇到索引的字典
print(" 索引到词汇的字典：", idx_to_word) # 输出索引到词汇的字典
print(" 词汇表大小：", voc_size) # 输出词汇表大小

'''
/Users/zbhuang/miniconda3/envs/jupyter-env01/bin/python /Users/zbhuang/MyDev/AIProjects/llm_gpt/02_Word2Vec/CBOW.py 
 词汇表： ['Niuzong', 'Xiaoxue', 'Kage', 'Xiaobing', 'Boss', 'Student', 'is', 'Mazong', 'Teacher']
 词汇到索引的字典： {'Niuzong': 0, 'Xiaoxue': 1, 'Kage': 2, 'Xiaobing': 3, 'Boss': 4, 'Student': 5, 'is': 6, 'Mazong': 7, 'Teacher': 8}
 索引到词汇的字典： {0: 'Niuzong', 1: 'Xiaoxue', 2: 'Kage', 3: 'Xiaobing', 4: 'Boss', 5: 'Student', 6: 'is', 7: 'Mazong', 8: 'Teacher'}
 词汇表大小： 9

Process finished with exit code 0
'''