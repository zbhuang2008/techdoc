import torch # 导入 torch
import torch.nn.functional as F # 导入 nn.functional
# 1. 创建两个张量 x1 和 x2
x1 = torch.randn(2, 3, 4) # 形状 (batch_size, seq_len1, feature_dim)
x2 = torch.randn(2, 5, 4) # 形状 (batch_size, seq_len2, feature_dim)
# 2. 计算原始权重
raw_weights = torch.bmm(x1, x2.transpose(1, 2)) # 形状 (batch_size, seq_len1, seq_len2)
# 3. 用 softmax 函数对原始权重进行归一化
attn_weights = F.softmax(raw_weights, dim=2) # 形状 (batch_size, seq_len1, seq_len2)
# 4. 将注意力权重与 x2 相乘，计算加权和
attn_output = torch.bmm(attn_weights, x2)  # 形状 (batch_size, seq_len1, feature_dim)

# 创建两个张量 x1 和 x2
x1 = torch.randn(2, 3, 4) # 形状 (batch_size, seq_len1, feature_dim)
x2 = torch.randn(2, 5, 4) # 形状 (batch_size, seq_len2, feature_dim)
print("x1:", x1)
print("x2:", x2)

# 计算点积，得到原始权重，形状为 (batch_size, seq_len1, seq_len2)
raw_weights = torch.bmm(x1, x2.transpose(1, 2))
print(" 原始权重：", raw_weights)

import torch.nn.functional as F # 导入 torch.nn.functional
# 应用 softmax 函数，使权重的值在 0 和 1 之间，且每一行的和为 1
attn_weights = F.softmax(raw_weights, dim=-1) # 归一化
print(" 归一化后的注意力权重：", attn_weights)

# 与 x2 相乘，得到注意力分布的加权和，形状为 (batch_size, seq_len1, feature_dim)
attn_output = torch.bmm(attn_weights, x2)
print(" 注意力输出 :", attn_output)

'''
/Users/zbhuang/miniconda3/envs/jupyter-env01/bin/python /Users/zbhuang/MyDev/AIProjects/llm_gpt/05_Attention/Dot-Product_Attention.py 
x1: tensor([[[ 1.5068, -0.9182,  1.1940,  0.9114],
         [-0.2027,  1.1503, -1.0877,  0.0250],
         [ 0.9337, -1.0754,  0.4400, -0.2650]],

        [[-0.5320,  0.3622, -0.0604, -1.1346],
         [-0.9015, -0.4513, -0.5163, -1.3436],
         [ 0.8236, -0.6024, -0.1954, -0.7812]]])
x2: tensor([[[-0.1581, -1.5567,  1.1472,  0.0121],
         [ 0.0893, -0.1801, -0.6017, -2.7364],
         [-0.1385, -0.9713, -1.2977, -0.8629],
         [ 0.0228, -1.1236,  0.1752, -0.0289],
         [-0.8966, -0.6178,  1.5118,  0.5404]],

        [[-0.7888,  0.2864,  0.8098, -0.9815],
         [ 2.3237, -0.7456, -0.5965,  0.2574],
         [ 2.0183,  0.7139, -1.2280, -1.1335],
         [-0.9389,  0.9460, -0.1025,  0.5894],
         [ 1.6120, -0.2625, -1.0160, -1.6150]]])
 原始权重： tensor([[[ 2.5719, -2.9124, -1.6527,  1.2490,  1.5137],
         [-3.0061,  0.3608,  0.3008, -1.4884, -2.1597],
         [ 2.0281,  0.7375,  0.5728,  1.3144,  0.3492]],

        [[ 1.5881, -1.7623,  0.5452,  0.1796,  0.9411],
         [ 1.4825, -1.7961,  0.0153, -0.3195,  1.3598],
         [-0.2137,  2.2783,  2.3575, -1.7835,  2.9458]]])
 归一化后的注意力权重： tensor([[[0.6127, 0.0025, 0.0090, 0.1632, 0.2126],
         [0.0156, 0.4517, 0.4253, 0.0711, 0.0363],
         [0.4577, 0.1259, 0.1068, 0.2242, 0.0854]],

        [[0.4639, 0.0163, 0.1635, 0.1134, 0.2429],
         [0.4314, 0.0163, 0.0995, 0.0712, 0.3816],
         [0.0200, 0.2420, 0.2620, 0.0042, 0.4718]]])
 注意力输出 : tensor([[[-0.2848, -1.2777,  1.0397,  0.1029],
         [-0.0520, -0.6210, -0.7385, -1.5853],
         [-0.1473, -1.1436,  0.4791, -0.3915]],

        [[ 0.2869,  0.2810, -0.0933, -0.9619],
         [ 0.4466,  0.1496, -0.1776, -1.1064],
         [ 1.8319, -0.1076, -0.9297, -1.0138]]])

Process finished with exit code 0
'''