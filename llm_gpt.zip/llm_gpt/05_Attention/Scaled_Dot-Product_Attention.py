import torch # 导入 torch
import torch.nn.functional as F # 导入 nn.functional
# 1. 创建两个张量 x1 和 x2
x1 = torch.randn(2, 3, 4) # 形状 (batch_size, seq_len1, feature_dim)
x2 = torch.randn(2, 5, 4) # 形状 (batch_size, seq_len2, feature_dim)
# 2. 计算张量点积，得到原始权重
raw_weights = torch.bmm(x1, x2.transpose(1, 2)) # 形状 (batch_size, seq_len1, seq_len2)
# 3. 将原始权重除以缩放因子
scaling_factor = x1.size(-1) ** 0.5
scaled_weights = raw_weights  / scaling_factor # 形状 (batch_size, seq_len1, seq_len2)
# 4. 对原始权重进行归一化
attn_weights  =  F.softmax(scaled_weights, dim=2) #  形 状 (batch_size,  seq_len1,  seq_len2)
# 5. 使用注意力权重对 x2 加权求和
attn_output = torch.bmm(attn_weights, x2)  # 形状 (batch_size, seq_len1, feature_dim)
print(attn_output)

'''
/Users/zbhuang/miniconda3/envs/jupyter-env01/bin/python /Users/zbhuang/MyDev/AIProjects/llm_gpt/05_Attention/Scaled_Dot-Product_Attention.py 
tensor([[[-1.1231e-01,  1.4745e+00,  6.2625e-01,  2.9775e-01],
         [ 8.5944e-03, -3.1411e-01, -2.6460e-04,  4.0018e-01],
         [-1.0808e-01,  9.2846e-01,  4.2508e-01,  3.4746e-01]],

        [[ 6.6952e-01, -7.4885e-01, -6.5658e-01, -9.8112e-01],
         [ 6.6441e-01, -8.0587e-02,  1.5049e-01,  8.5194e-01],
         [ 6.0474e-01, -1.2725e+00, -7.0424e-01, -1.4465e+00]]])

Process finished with exit code 0
'''