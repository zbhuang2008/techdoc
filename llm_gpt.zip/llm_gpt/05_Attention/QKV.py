import torch
import torch.nn.functional as F
#1. 创建 Query、Key 和 Value 张量
q = torch.randn(2, 3, 4) # 形状 (batch_size, seq_len1, feature_dim)
k = torch.randn(2, 4, 4) # 形状 (batch_size, seq_len2, feature_dim)
v = torch.randn(2, 4, 4) # 形状 (batch_size, seq_len2, feature_dim)
# 2. 计算点积，得到原始权重，形状为 (batch_size, seq_len1, seq_len2)
raw_weights = torch.bmm(q, k.transpose(1, 2))
# 3. 将原始权重进行缩放（可选），形状仍为 (batch_size, seq_len1, seq_len2)
scaling_factor = q.size(-1) ** 0.5
scaled_weights = raw_weights / scaling_factor
# 4. 应用 softmax 函数，使结果的值在 0 和 1 之间，且每一行的和为 1
attn_weights = F.softmax(scaled_weights, dim=-1) # 形状仍为 (batch_size, seq_len1, seq_len2)
# 5. 与 Value 相乘，得到注意力分布的加权和 , 形状为 (batch_size, seq_len1, feature_dim)
attn_output = torch.bmm(attn_weights, v)
print(attn_output);

'''
/Users/zbhuang/miniconda3/envs/jupyter-env01/bin/python /Users/zbhuang/MyDev/AIProjects/llm_gpt/05_Attention/QKV.py 
tensor([[[ 0.2235, -0.4103, -0.0162, -0.0527],
         [-0.0054, -0.0225,  0.0050,  0.7108],
         [ 0.6707, -1.1324,  0.2408, -0.8600]],

        [[ 0.6895, -0.5492, -0.1089,  1.0903],
         [-0.5631, -0.0058,  1.4361,  0.9781],
         [ 0.7872, -0.6514, -0.0200,  1.1806]]])

Process finished with exit code 0
'''